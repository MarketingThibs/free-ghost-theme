# Read Me

[TOC]

## Files

### The main files are

- `default.hbs` - The main template file
- `index.hbs` - Used for the home page
- `post.hbs` - Used for individual posts
- `page.hbs` - Used for individual pages
- `tag.hbs` - Used for tag archives
- `author.hbs` - Used for author archives
- `error-404.hbs` - Used for 404 styling
- `error.hbs` - Used for any other erros
- `subscribe.hbs` - Used as thank you page for subscription

### The partials are

- `subscribe_form.hbs` - Used to style the subsciption form
- `site-nav.hbs ` - Site nav
- `previous-next-posts.hbs` - Used for displaying previous and next posts
- `post-card.hbs` - Used to diplay the article
- `floating-header.hbs` - Used for sharing this modal
- `byline-single.hbs`
- `byline-multiple.hbs`





## Design

This theme is using [UIKit framework](https://getuikit.com/docs/introduction) and custom code. The style sheet used is located under `asset/built/uikit-3.0.0-rc.20/css/uikit.min.css`

### Background Image

The template Background image is located under `assets/img/bg-blog-pattern.png`

### Colors

CSS variables are used here to define the colors. You can edit the variables to update all the colors or define new ones.

```css
/* Main colors variables accross the css */
:root {
    --orange: #f5ab35;
    --intenseorange: #f9690e;
    --darkblue: #22313f;
    --lightgrey: #eeeeee;
    --metagrey: #999;
    --darkgrey: #333;
    --lighterdarkblue: #3f5d79;
    --lightbrown: #945d5d;
}
/* end Main colors */
```

### Custom Style CSS

Some CSS has been added in `uikit.css`. It starts at the bottom of the code. You can look for it by searching `/* Additional custom style */`.



## Search Function

The search is not available by default, therefore [GhostHunter](https://github.com/jamalneufeld/ghostHunter) third party solution is used here. It searched from key press and accros tags, articles...

You can refer to the Git link above. The search script is in the `default.hbs` file

```html
{{!-- Search Script --}}
<script type="text/javascript" src="{{asset "ghostHunter/dist/jquery.ghosthunter.js"}}"></script>
<script>
	$("#search-field").ghostHunter({
    	results: "#results",
        onKeyUp: "true"
    });
</script>
```





## Editing

### code blocks

You can select the default code block in the post editor or pick the _markdown_ option and then indicates the language so the code will be colored thanks to [Prism JS](https://prismjs.com/) (located `assets/prism`)

```markdown
​```html
color code here
​```
```



Enjoy :) 